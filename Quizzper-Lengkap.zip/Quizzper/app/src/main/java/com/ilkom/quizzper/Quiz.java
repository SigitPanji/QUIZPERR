package com.ilkom.quizzper;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Quiz extends AppCompatActivity {
    TextView TextSoal, Nilai;
    EditText JawabanPengguna;
    Button Submit;
    int x=0;
    int arr;
    int benar;
    String jawaban;

    Soal quiz = new Soal();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        Nilai = (TextView) findViewById(R.id.txtNilai);
        TextSoal = (TextView) findViewById(R.id.txtSoal);
        JawabanPengguna = (EditText) findViewById(R.id.Jawaban);
        Submit = (Button) findViewById(R.id.btnSubmit);

        mulaiQuiz();

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Koreksi();
            }
        });
    }

    public void mulaiQuiz(){
        JawabanPengguna.setText(null);
        arr = quiz.pertanyaan.length;
        if(x >= arr){
            String NilaiAkhir = String.valueOf(benar);
            Intent i = new Intent(Quiz.this, Nilai.class);
            i.putExtra("Nilai",NilaiAkhir);
            startActivity(i);
        }else{
            TextSoal.setText(quiz.getPertanyaan(x));
            jawaban = quiz.getJawabanBenar(x);
        }
        x++;
    }

    public void Koreksi(){
        if(!JawabanPengguna.getText().toString().isEmpty()){
            if(JawabanPengguna.getText().toString().equalsIgnoreCase(jawaban)){
                benar = benar + 10;
                Nilai.setText(""+benar);
                Toast.makeText(this, "Jawaban Anda Benar", Toast.LENGTH_SHORT).show();
                mulaiQuiz();
            }else{
                Nilai.setText(""+benar);
                Toast.makeText(this, "Jawaban Anda Salah", Toast.LENGTH_SHORT).show();
                mulaiQuiz();
            }
        }else{
            Toast.makeText(this, "Isi Jawaban Anda!!", Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed(){
        Toast.makeText(this, "Selesaikan Quiz Terlebih Dahulu", Toast.LENGTH_SHORT).show();
    }
}
