package com.ilkom.quizzper;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class Nilai extends AppCompatActivity {
    TextView Nilai;
    Button Menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nilai);

        Nilai = (TextView) findViewById(R.id.txtNilai);
        Menu = (Button) findViewById(R.id.Menu);

        setSkor();

        Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Nilai.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    public void setSkor(){
        String NilaiAkhir = getIntent().getStringExtra("Nilai");

        Nilai.setText("Nilai : "+NilaiAkhir);
    }

    public void onBackPressed(){
        Toast.makeText(this, "Silahkan kembali ke menu home", Toast.LENGTH_SHORT).show();
    }
}
