package com.ilkom.quizzper;

public class Soal {
    public String pertanyaan[] = {
            "1+3 = ...",
            "Negara Republik Kesatuan Indonesia",
            "Android versi 5 bernama",
            "Universitas Lampung",
            "Presiden Indonesia saat ini",
    };

    private String jawabanBenar[] = {
            "4",
            "NKRI",
            "Lollipop",
            "UNILA",
            "Jokowi",
    };

    public String getPertanyaan(int x) {
        String soal = pertanyaan[x];
        return soal;
    }

    public String getJawabanBenar(int x) {
        String jawaban = jawabanBenar[x];
        return jawaban;
    }
}
