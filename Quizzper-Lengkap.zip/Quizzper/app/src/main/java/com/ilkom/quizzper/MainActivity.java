package com.ilkom.quizzper;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button quiz = (Button) findViewById(R.id.btn_mulai);
        Button app = (Button) findViewById(R.id.btn_about);
        Button out = (Button) findViewById(R.id.btn_keluar);

        quiz.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent i = new Intent(MainActivity.this,Quiz.class);
                startActivity(i);
            }
        });
        app.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent i = new Intent(MainActivity.this,About.class);
                startActivity(i);
            }
        });
        out.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                finish();
                System.exit(0);
            }
        });
    }
}
