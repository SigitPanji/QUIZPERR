package com.ilkom.quizzper.ui.main;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

public class PageViewModel extends ViewModel {

    private MutableLiveData<Integer> mIndex = new MutableLiveData<>();
    private LiveData<String> mText = Transformations.map(mIndex, new Function<Integer, String>() {
        @Override
        public String apply(Integer input) {
            if(input == 1){
                return "Aplikasi sederhana ini adalah aplikasi kuis yang berisi tentang ilmu pengetahuan umum.\nDidalam kuis ini terdapat 5 pertanyaan yang disediakan.\njika anda sudah selesai menjawab semua pertanyaan maka akan muncul skor yang anda dapatkan.";
            }else {
                return "Ester Caroline - 1717051002\n\nArie Cahyadi - 1717051056\n\nYulita Sari - 1717051072\n\nSigit Panji P - 1757051002";
            }
        }
    });

    public void setIndex(int index) {
        mIndex.setValue(index);
    }

    public LiveData<String> getText() {
        return mText;
    }
}